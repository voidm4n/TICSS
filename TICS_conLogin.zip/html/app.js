const apiKey = '%k1ksk7XCoS$_MdZdWguub96h2DqS3$LrnJy$n1O%%x6jiDyof-ecO%$$fMinnKP';
const fileId = 'Data-base';

fetch(`https://sheet.best/api/sheets/1621c702-c1e1-4170-8e18-e2dc3d035496`, {
  headers: {
    'X-API-KEY': apiKey,
  },
})
  .then(response => response.json())
  .then(data => generateTableFromExcel(data))
  .catch(error => console.error(error));

function generateTableFromExcel(excelData) {
  const table = document.getElementById('excel-table');

  excelData.forEach(row => {
    const newRow = document.createElement('tr');
    newRow.innerHTML = `
      <td>${row.NOMBRE}</td>
      <td>${row.FECHA}</td>
      <td>${row.VALOR}</td>
      <td>${row.HORA}</td>
    `;
    table.querySelector('tbody').appendChild(newRow);
  });

  generateChartFromExcel(excelData);
  table.classList.add('table-fade-in');
}

function generateChartFromExcel(excelData) {
  // Obtén los datos para el gráfico a partir de los datos del archivo Excel
  const labels = excelData.map(row => row.NOMBRE);
  const values = excelData.map(row => row.VALOR);

  // Configura el contexto del gráfico
  const ctx = document.getElementById('myChart').getContext('2d');

  // Crea el gráfico utilizando Chart.js
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'Nivel de Gas',
          data: values,
          backgroundColor: 'rgba(75, 192, 192, 0.2)',
          borderColor: 'rgba(75, 192, 192, 1)',
          borderWidth: 1,
        },
      ],
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  });
}



